x = 10;
y = 10;
dir = "RIGHT";
arr = [];
dead = false;
snakelen = 3;
snack = [100, 100]

function preload(){
  //song = loadSound('assets/BossMain.wav');
}

function setup() {
  createCanvas(400, 400);
  //song = loadSound('assets/BossMain.wav');
  frameRate(20);
  //song.play();
}

function draw() {
  if (dead == true) {
    background(256, 0, 0);
    text("you died!", 200, 200)
    //song.stop();
    if (keyCode === ENTER) {
      x = 10;
      y = 10;
      dir = "RIGHT";
      arr = [];
      dead = false;
      snakelen = 3;
      snack = [100, 100]
      //song.play();
    }
  } else {
    background(random(0, 255), random(0, 255), random(0, 255));
    moveBlock();
    fill(256)
    arr.forEach(x => rect(x[0], x[1], 10, 10));
    if (arr.slice(0, arr.length).find(a => a[0] == x && a[1] == y)) {
      dead = true;
    }
    if (arr.length > snakelen - 1) {
      arr.shift();
    }

    arr.push([x, y]);

    fill(random(0, 255), random(0, 255), random(0, 255))
    rect(snack[0], snack[1], 10, 10)
    if (arr[arr.length - 1][0] == snack[0]
      && arr[arr.length - 1][1] == snack[1]) {
      snakelen++
      snack[0] = (Math.floor(random(width) / 10) * 10)
      snack[1] = (Math.floor(random(height) / 10) * 10)
      //frameRate(3 + snakelen)
    }
  }
}

function moveBlock() {
  if (dir == "LEFT") {
    if (x > 0) {
      x -= 10;
    } else {
      x = width - 10
    }
  }
  if (dir == "RIGHT") {
    if (x < width - 10) {
      x += 10;
    } else {
      x = 0
    }
  }

  if (dir == "DOWN") {
    if (y < height - 10) {
      y += 10;
    } else {
      y = 0
    }
  }
  if (dir == "UP") {
    if (y > 0) {
      y -= 10;
    } else {
      y = height - 10
    }
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    dir = "LEFT";
  }
  if (keyCode === UP_ARROW) {
    dir = "UP";
  }
  if (keyCode === RIGHT_ARROW) {
    dir = "RIGHT";
  }
  if (keyCode === DOWN_ARROW) {
    dir = "DOWN";
  }
  console.log(dir);
}

