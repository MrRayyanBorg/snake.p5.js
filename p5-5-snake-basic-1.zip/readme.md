###


### P5.JS Workshop Instructions
This is a working copy of the game Snake. 

### 1 Comment the code
Your comments should answer the following questions:
- 1. How are arrays used to contain the body of the snake?
<!---snake body = 3 , when snack eaten, snake body array + 1, and snack is respawned -->
- 2. How long is the maximum possible snake that could conceivably exist on the play board?
<!---canvas area = 160,000, block size = 10*10, max snake size = 1,600 blocks-->
- 3. How is the snack drawn?
<!---rect() function -->
- 4. How is the snack regenerated?
<!---random width,height -->
- 5. What is responsible for the motion blur? (remember Monday)
- 6. What is responsible for the increased speed?
 <!---framerate--->
- 7. What are the lose conditions? Is it possible to lose the game? How?
<!-- run into yourself e.g. pressing down then up-->
- 8. What are the win conditions? Is it possible to win the game? How?
<!--collect all snacks until size of board...? -->
- 9. What is the function of the **moveBlock()** function? Is any code repeated here?
- 10. What is the function of the **keyPressed()** function? Is any code repeated here?
<!--Every time a key is pressed, snake changes direction, yes -->

### 2 Refactor
Are there any changes that you can make to improve the code design while retaining the same functionality? Are there any changes that you could make to improve security?

Open your console (you may have to open in a new tab using the second button on the top right)
type the following 
```snakelen = 30 ```
What happens? how can we avoid this?

Can we use additional functions for this? Can we use classes or objects to redesign the code?

### 3 Add features
Features that have been requested include

- 1. the ability to have a score (perhaps using the **text()** function?) 
- 2. the ability to reset using a keypress if the snake gets too long - currently refreshing is the only way to do this.
- 3. the ability to change the snack colour after every run through
- 4. colour changing background - nothing too jarring
- 5. the ability to save the scores from games and console.log them after every game finishes
- 6. the ability to enter a name for each attempt (perhaps using the **prompt()** function)
- 7. the ability to save these scores to a text file or a database.





### P5.JS Template Instructions
Welcome to the Template P5 Repo, used to make P5 work in [repl.it](../).
Run should bring up a simple sketch.
To edit the sketch, see [sketch.js](./emptyp5#sketch.js)

You can find the reference, with the descriptions of basic P5 functions, [here](https://p5js.org/reference/)
You can also find documentation for JavaScript [here](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
There is an excellent web editor [here](https://editor.p5js.org/) - this was only made to facilitate multiplayer!
 
[index.html](./emptyp5#index.html) only needs to be changed to add a title, or instructions.
If you are coming across this randomly, you may want to edit the index.html to include the latest version of P5, found [here](https://p5js.org/get-started/#settingUp).
